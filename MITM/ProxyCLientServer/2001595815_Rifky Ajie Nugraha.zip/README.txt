ANP 3 Proxy Server

Made in Kali Linux
Supported in Linux (Might not supported in WindowsOS)

---------------Simple Chat With Proxy in The Middle v.1.0.20-------------------
1. Run Proxy and client2 first (client2 select menu 1)
2. Run client1
3. Enjoy chatting :)

Notes : - 1000% legit original no copas

REFERENCES---------------------------------------------------------------------

-> kk asleb
-> https://stackoverflow.com/questions/23700569/reading-port-number-as-an-argument-and-do-stuff
-> https://programminghistorian.org/lessons/manipulating-strings-in-python
